package nicxcin.io;

public class MapFactory {
    public static Map createMap(int level) {
        Map m = new Map(
                createTreeMap(),
                createSandMap(),
                createHeightMap(level)
        );

        return m;
    }


    private static float[][] createHeightMap(int level) {
        int size = 10;

        float[][] heightMap = new float[size][size];

        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {

                heightMap[x][y] = (float) Terrain.compute(level, x, y);
            }
        }
        return heightMap;
    }

    private static Tree[] createTreeMap() {
        Tree[] t = new Tree[10];

        return t;
    }


    private static SandSpot[] createSandMap() {
        SandSpot[] s = new SandSpot[10];

        return s;
    }
}
