package nicxcin.io;

public class GameConstants {

    public static int MENU_HEIGTH = 500;
    public static int MENU_WIDTH = 500;

    public static int GAME_HEIGTH = 1000;
    public static int GAME_WIDTH = 1000;
}
