package nicxcin.io;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.CameraInputController;
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.viewport.ExtendViewport;

import java.util.ArrayList;
//import com.mygdx.managers.CrazyPuttingGame;

public class GameScreen extends InputAdapter implements Screen {

    CrazyPuttingGame game;
    ShapeRenderer renderer;
    ExtendViewport viewport;
    SpriteBatch batch;

    private PerspectiveCamera cam;
    private Model model;
    private ModelInstance instance;
    private ModelBatch modelBatch;
    private Environment environment;
    private CameraInputController camController;
    private MeshPartBuilder meshPartBuilder;

    private boolean loaded = false;
    private boolean ready = false;


    GameScreen(CrazyPuttingGame game){
        this.game = game;
    }


    @Override
    public void render (float delta) {
        if(loaded && ready) {
            Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

            camController.update();
            modelBatch.begin(cam);
            modelBatch.render(instance, environment);
            modelBatch.end();
        } else if(!loaded) {
            loaded = true;
            loadLevel();
        }
    }

    @Override
    public void dispose () {

    }

    @Override
    public void show(){
        renderer = new ShapeRenderer();
        batch = new SpriteBatch();

        viewport = new ExtendViewport(GameConstants.GAME_WIDTH, GameConstants.GAME_HEIGTH);
        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}


    public class  LevelInput implements Input.TextInputListener {
        @Override
        public void input (String text) {
            Map m = MapFactory.createMap(Integer.parseInt(text));
            Gdx.app.postRunnable(() -> createLevel(m));
        }

        @Override
        public void canceled () {

        }
    }

    private void loadLevel() {
        LevelInput listener = new LevelInput();
        Gdx.input.getTextInput(listener, "Enter Level Number:", "", "");

    }

    private void createLevel(Map m) {
        modelBatch = new ModelBatch();

        cam = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        cam.position.set(10f, 10f, 10f);
        cam.lookAt(0,0,0);
        cam.near = 1f;
        cam.far = 300f;
        cam.update();

        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.4f, 0.4f, 0.4f, 1f));
        environment.add(new DirectionalLight().set(0.8f, 0.8f, 0.8f, -1f, -0.8f, -0.2f));

        camController = new CameraInputController(cam);
        Gdx.input.setInputProcessor(camController);


        int s = m.getSize();
        float[][] h = m.getHeightMap();

        ArrayList<Face> faces = new ArrayList<>(2*(s)*(s));

        for (int x = 0; x < h[0].length-1; x++) {
            for (int y = 0; y < h.length-1; y++) {
                faces.add( new Face(new Vector3(x,h[x][y+1],y+1),   new Vector3(x+1,h[x+1][y],y), new Vector3(x,h[x][y],y),   Color.GREEN));
                faces.add( new Face(new Vector3(x+1,h[x+1][y+1],y+1), new Vector3(x+1,h[x+1][y],y), new Vector3(x,h[x][y+1],y+1), new Color(0,0.6f,0,1)));
            }
        }
        

        ModelBuilder modelBuilder = new ModelBuilder();
        modelBuilder.begin();

        int attr = VertexAttributes.Usage.Position  | VertexAttributes.Usage.Normal | VertexAttributes.Usage.TextureCoordinates;

        for(Face face : faces) {

            modelBuilder.part(
                    "face"+face.getID(),
                    GL20.GL_TRIANGLES,
                    attr,
                    new Material( ColorAttribute.createDiffuse(face.getColor()))
            ).triangle(face.getA(), face.getB(), face.getC());

        }

        instance = new ModelInstance(modelBuilder.end(), 0, 0, 0);
        ready = true;
    }
}
