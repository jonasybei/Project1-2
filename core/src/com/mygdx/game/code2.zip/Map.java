package nicxcin.io;

class Map {
    private float[][] heightMap; //the height related to a specific x and y
    private final double sandFrinction = 0.6;
    private final double grassFriction = 0.3;
    private Tree[] treeMap;
    private SandSpot[] sandMap;
    private int size;

    Map(Tree[] atreeMap, SandSpot[] asandMap, float[][] aHeightMap){
        this.treeMap = atreeMap;
        this.sandMap = asandMap;
        this.heightMap = aHeightMap;
    }

    public int getSize() {
        return heightMap.length;
    }

    public float[][] getHeightMap() {
        return heightMap;
    }
}
